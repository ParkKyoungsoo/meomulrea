<template>
  <v-main>
    <v-container>
      카테고리에 해당하는 가게 목록들
      <div>{{ $route.params.category }}</div>
      <div>{{ this.getLocation.dong }}</div>
      <v-row>
        <v-col class="shopList">
          <v-card
            class="mx-auto"
            max-width="320"
            outlined
            v-for="(item, index) in this.getShopList.shopList"
            :key="index"
          >
            <v-col>
              <v-row justify="center">
                <div>{{ item.store_name }}</div>
              </v-row>
              <v-row justify="center">
                <v-list-item-avatar tile size="200" color="grey" />
              </v-row>
            </v-col>

            <v-card-actions>
              <v-btn
                depressed
                color="primary"
                @click="goToShopDetail(item.store_id)"
                >가게 보러가기</v-btn
              >
            </v-card-actions>
          </v-card>
        </v-col>
        <v-col>
          <kakaoMap :storeData="loc" :category="category" />
        </v-col>
      </v-row>
    </v-container>
  </v-main>
</template>

<script>
import axios from "axios";
import kakaoMap from "../components/KakaoMap.vue";
import { mapGetters } from "vuex";

export default {
  data() {
    return {
      data: {
        loc: 0,
        category: "",
        shopList: "",
      },
    };
  },
  components: {
    kakaoMap,
  },

  computed: {
    ...mapGetters("location", ["getLocation"]),
    ...mapGetters("shopList", ["getShopList"]),
  },

  created: function() {
    this.loc = this.getLocation;
    this.category = this.$route.params.category;
    this.shopList = this.getShopList;
    console.log("shopList : ", this.shopList);
  },

  methods: {
    goToShopDetail: function(shopId) {
      this.$router.push("/storedetail/" + shopId);
    },
    test: function() {
      console.log("loc", this.loc);
    },
    showShopList: function() {
      axios({
        method: "GET",
        url: ``,
        params: {
          page: 1,
          pagesize: 5,
        },
      })
        .then((response) => {
          this.locationData = response.data;
          console.log(this.locationData);
        })
        .catch((ex) => {
          console.log("ERR!!!!! : ", ex);
        });
    },
  },
};
</script>
<style>
.shopList {
  display: flex;
  justify-content: center;
  flex-wrap: wrap;
}
</style>
